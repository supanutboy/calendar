import controller.Controller;
import model.Calender;

public class StartApp {
	public static void main(String[] args) {
		Controller controller = new Controller();
		controller.startApplication();
	}	
}
