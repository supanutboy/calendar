package model;

public class Memo {
	public void updateDay(int lastday) {
		
	}
}
