package viewAndAction;

public class View {
	String date;
	public View(String date) {
		this.date=date;
	}
	public void createFrame() {
		// TODO Auto-generated method stub
		
	}

}
