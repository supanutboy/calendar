package viewAndAction;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.omg.CORBA.portable.ValueOutputStream;

import model.Memo;

import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.GridLayout;
import java.awt.TextArea;

import javax.swing.JTextArea;

public class GUIDate extends JFrame {
	private Memo memo;
	private JPanel contentPane;
	JComboBox comboBoxDay;
	//private JTextField textField;
	private JTextField[] textField = new JTextField[42];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUIDate frame = new GUIDate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUIDate() {
		memo =new Memo();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(140, 450, 650, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnToday = new JButton("Today");
		btnToday.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnToday.setBounds(6, 6, 117, 29);
		contentPane.add(btnToday);
		
		JLabel lblDate = new JLabel("Day: ");
		lblDate.setBounds(468, 43, 36, 16);
		contentPane.add(lblDate);
		
		JLabel lblSun = new JLabel("SUN");
		lblSun.setBounds(53, 78, 61, 16);
		contentPane.add(lblSun);
		
		JLabel lblMon = new JLabel("MON");
		lblMon.setBounds(106, 78, 61, 16);
		contentPane.add(lblMon);
		
		JLabel lblTue = new JLabel("TUE");
		lblTue.setBounds(165, 78, 61, 16);
		contentPane.add(lblTue);
		
		JLabel lblNewLabel = new JLabel("WED");
		lblNewLabel.setBounds(220, 78, 61, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblThu = new JLabel("THU");
		lblThu.setBounds(277, 78, 36, 16);
		contentPane.add(lblThu);
		
		JLabel lblFri = new JLabel("FRI");
		lblFri.setBounds(342, 78, 61, 16);
		contentPane.add(lblFri);
		
		JLabel lblSat = new JLabel("SAT");
		lblSat.setBounds(395, 78, 61, 16);
		contentPane.add(lblSat);
		
		JLabel lblMemo = new JLabel("MEMO");
		lblMemo.setBounds(597, 348, 61, 16);
		contentPane.add(lblMemo);
		
		//textField = new JTextField();
//		textField.setBounds(444, 81, 186, 225);
//		contentPane.add(textField);
//		textField.setColumns(10);
//		
		JButton btnSave = new JButton("save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSave.setBounds(468, 318, 117, 29);
		contentPane.add(btnSave);
		
		JButton btnClear = new JButton("clear");
		btnClear.setBounds(468, 343, 117, 29);
		contentPane.add(btnClear);
		
		JComboBox comboBoxMonth = new JComboBox(getMonth());
		comboBoxMonth.setBounds(43, 39, 123, 27);
		contentPane.add(comboBoxMonth);
		
		JComboBox comboBoxYear = new JComboBox(getYear());
		comboBoxYear.setBounds(178, 39, 123, 27);
		contentPane.add(comboBoxYear);
		
		JButton btnShow = new JButton("SHOW");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int year = Integer.parseInt(comboBoxYear.getSelectedItem().toString());
				int month = comboBoxMonth.getSelectedIndex();
				showCalender(year,month);
			}
		});
		btnShow.setBounds(320, 37, 117, 29);
		contentPane.add(btnShow);
		
		JPanel panel = new JPanel();
		panel.setBounds(30, 105, 403, 256);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(6,7, 0, 0));
			
		JTextArea textArea = new JTextArea();
		textArea.setBounds(467, 105, 154, 209);
		contentPane.add(textArea);
		
		comboBoxDay = new JComboBox();
		comboBoxDay.setBounds(500, 42, 85, 21);
		contentPane.add(comboBoxDay);
		
		JLabel lblStep = new JLabel("Step 1:Choose Month&Year");
		lblStep.setBounds(135, 11, 204, 16);
		contentPane.add(lblStep);
		
		JLabel lblStep_1 = new JLabel("Step2:Choose Day");
		lblStep_1.setBounds(468, 11, 136, 16);
		contentPane.add(lblStep_1);
		
		JButton btnShow_1 = new JButton("SHOW");
		btnShow_1.setBounds(454, 71, 117, 29);
		contentPane.add(btnShow_1);
		
		
		for(int i=0;i<textField.length;i++) {
			textField[i] = new JTextField();
			textField[i].setEditable(false);
			textField[i].setHorizontalAlignment(JTextField.CENTER);
			panel.add(textField[i]);
		}
	}
protected void showCalender(int yearSelect,int monthSelect) {
		int[] monthDay = {31,28,31,30,31,30,31,31,30,31,30,31};
		int year=1900;
		int month=0;
		int day = 2;
		while (check(yearSelect,monthSelect,year,month)) {
		if (month==1 && leapYear(year)) {
			day=day+29;
		}
		else {
			day =day+monthDay[month];
		}
		month++;
		if(month == 12) {
			month=0;
			year++;
		}
		day=day%7;
		}
		
		
		
		for (int i=0;i<textField.length;i++) {
			textField[i].setText("");
		}
		int lastValue =monthDay[monthSelect];	
		if (monthSelect==1 && leapYear(yearSelect)) {
			lastValue++;
		}
		this.updateDay(lastValue);
		for (int i=1,j=day;i<=lastValue;i++,j++) {
			textField[j].setText(String.valueOf(i));
		}
		
	}
private void updateDay(int lastday) {
	int[] list = new int[lastday];
	for (int i=1;i<lastday+1;i++) {
		comboBoxDay.addItem(i);
	}
}
private boolean leapYear(int year) {
	boolean ans = false;
	if (year % 4==0) {
		ans=true;
	if (year %100==0) {
		ans =false;
		
	}
	if (year %400==0) {
		ans=true;
	}
	}
	return false;
}

private boolean check(int comboBoxYear, int comboBoxMonth, int year, int month) {
	if (comboBoxYear==year && comboBoxMonth==month) {
		return false;
	}
	return true;
}

//	public String[] calYear() {
//		String[] str = new String[201];
//		for(int i=1900,j=0;i<=2100;i++,j++) {
//			str[j]=String.valueOf(i);
//		}
//		return null;
//	}
	private String[] getYear() {
		String[] str = new String[201];
		for(int i=1900,j=0;i<=2100;i++,j++) {
			str[j]=String.valueOf(i);
		}
		return str;
		}


	private String[] getMonth() {
		String[] str = {"January","Febryary","Match","April","May","June","July","August","September","October","November","December"};
		return str;
	}
}
