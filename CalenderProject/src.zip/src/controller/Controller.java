package controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import viewAndAction.View;

public class Controller {

	public void startApplication() {
		Date currentDate = new Date();
		SimpleDateFormat date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		System.out.println(date.format(currentDate));
		View view = new View((date.format(currentDate)));
	}

}
